#pragma once

const size_t length_x = 10;
const size_t height_x = 2;
const size_t length_y = 10;

const size_t SIZE = 1000;

extern const float x_train[length_x][height_x];
extern const int y_train[length_y];
